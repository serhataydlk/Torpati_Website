//  var swiper = new Swiper(".mySwiper", {
//      spaceBetween: 30,
//      centeredSlides: true,
//      autoplay: {
//           delay: 2500,
//         disableOnInteraction: false,
//       },
//     pagination: {
//          el: ".swiper-pagination",
//         clickable: true,
//      },
//     navigation: {
//         nextEl: ".swiper-button-next",
// prevEl: ".swiper-button-prev",
//     },
//  });


// function onContentScroll() {
//     if ($('nav.header').hasClass('pxp-bigger') || $('nav.header').hasClass('pxp-no-bg')) {
//         if (window.pageYOffset > 20) {
//             $('nav.header').addClass('header-is-sticky');
//         } else {
//             $('nav.header').removeClass('header-is-sticky');
//         }
//     } else if ($('nav.header').hasClass('pxp-no-bg')) {
//         if (window.pageYOffset > 0) {
//             $('nav.header').addClass('header-is-sticky');
//         } else {
//             $('nav.header').removeClass('header-is-sticky');
//         }
//     } else {
//         if (window.pageYOffset > 93) {
//             $('nav.header').addClass('header-is-sticky');
//         } else {
//             $('nav.header').removeClass('header-is-sticky');
//         }
//     }
// }

 window.onscroll = function () {
     onContentScroll();
 };
 onContentScroll();

  //Sayacı güncellemek için özelleştirilmiş bir fonksiyon
  function updateCounter(id,target, duration) {
     let count = 0;
     const counterElement = document.getElementById(id);
     const increment = target / (duration / 1000); // Hız hesaplaması

     function update() {
         count += increment;
         if (count < target) {
             counterElement.textContent = Math.floor(count); // Sayacı güncelle
             requestAnimationFrame(update); // Bir sonraki güncellemeyi planla
         } else {
             counterElement.textContent = target; // Hedef değere ulaşıldığında tamamla
         }
     }

     update(); // İlk güncellemeyi başlat
 }

// Sayaçı 60.000'e 5 saniyede çıkarmak için çağırın

  // Intersection Observer ile kontrolcü eklemek

//   document.getElementById('next').onclick = 
// document.getElementById('prev').onclick = function(){
//     let lists = document.querySelectorAll('.item');
//     document.getElementById('slide').prepend(lists[lists.length - 1]);
// }
  

var swiper = new Swiper(".mySwiper", {
    spaceBetween: 10,
    slidesPerView: 4,
    freeMode: true,
    watchSlidesProgress: true,
});
var swiper2 = new Swiper(".mySwiper2", {
    spaceBetween: 10,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    thumbs: {
        swiper: swiper,
    },
});






